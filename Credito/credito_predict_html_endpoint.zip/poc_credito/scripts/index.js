// Gets a reference to the form element
var form = document.getElementById("form");
const labelResult = document.getElementById("labelResult");

async function sendData(e) {
  e.preventDefault();
  const data = [
    [
      parseInt(e.target["credito_coaplicante"].value),
      parseInt(e.target["credito_fiador"].value),
      parseInt(e.target["financiamento_outro_lugar"].value),
      e.target["tipo_emprego"].value,
      e.target["conta_corrente_valor"].value,
      parseInt(e.target["outros_creditos_aqui"].value),
      parseInt(e.target["finance__credits__other_banks"].value),
      parseInt(e.target["numero_dependentes"].value),
      e.target["investimentos_valor"].value,
      parseInt(e.target["duracao_residencia"].value),
      parseInt(e.target["valor_solicitado"].value),
      e.target["tem_telefone"].value,
      parseInt(e.target["duracao_emprego"].value),
      parseInt(e.target["duracao_credito"].value),
      e.target["historico_credito"].value,
      e.target["financiamento_outros_bens"].value,
      e.target["proposito_credito"].value,
      e.target["tipo_residencia"].value,
      parseInt(e.target["receita_disponivel"].value),
    ],
  ];

  try {
    const response = await fetch(
      "https://d2rtappwdg.execute-api.us-east-2.amazonaws.com/teste",
      {
        method: "POST",
        mode: "cors",
        cache: "no-cache",
        credentials: "same-origin",
        headers: {
          "Content-Type": "application/json",
        },
        redirect: "follow",
        referrerPolicy: "no-referrer",
        body: JSON.stringify({ data }),
      }
    );

    const result = await response.json();
    const { predictions } = JSON.parse(result.body);
    const { predicted_label } = predictions[0];

    console.log(predicted_label);

    if (predicted_label === 0) {
      labelResult.innerHTML = "CRÉDITO APROVADO";
      labelResult.classList.add("approved");
      labelResult.classList.remove("denied");
    } else {
      labelResult.innerHTML = "CRÉDITO REJEITADO";
      labelResult.classList.add("denied");
      labelResult.classList.remove("approved");
    }
  } catch (error) {
    console.log("ERROR", error);
  }
}

function clean(e) {
  labelResult.innerHTML = "-";
  labelResult.classList.remove("denied");
  labelResult.classList.remove("approved");
}

// Adds a listener for the "submit" event.
form.addEventListener("submit", sendData);
