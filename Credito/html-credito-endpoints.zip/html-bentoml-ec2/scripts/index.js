// Gets a reference to the form element
var form = document.getElementById("form");
const labelResult = document.getElementById("labelResult");

async function sendData(e) {
  e.preventDefault();
  const data = [
    {
      credito_coaplicante: parseInt(e.target["credito_coaplicante"].value),
      credito_fiador: parseInt(e.target["credito_fiador"].value),
      financiamento_outro_lugar: parseInt(
        e.target["financiamento_outro_lugar"].value
      ),
      tipo_emprego: e.target["tipo_emprego"].value,
      conta_corrente_valor: e.target["conta_corrente_valor"].value,
      outros_creditos_aqui: parseInt(e.target["outros_creditos_aqui"].value),
      finance__credits__other_banks: parseInt(
        e.target["finance__credits__other_banks"].value
      ),
      numero_dependentes: parseInt(e.target["numero_dependentes"].value),
      investimentos_valor: e.target["investimentos_valor"].value,
      duracao_residencia: parseInt(e.target["duracao_residencia"].value),
      valor_solicitado: parseInt(e.target["valor_solicitado"].value),
      tem_telefone: e.target["tem_telefone"].value,
      duracao_emprego: parseInt(e.target["duracao_emprego"].value),
      duracao_credito: parseInt(e.target["duracao_credito"].value),
      historico_credito: e.target["historico_credito"].value,
      financiamento_outros_bens: e.target["financiamento_outros_bens"].value,
      proposito_credito: e.target["proposito_credito"].value,
      tipo_residencia: e.target["tipo_residencia"].value,
      receita_disponivel: parseInt(e.target["receita_disponivel"].value),
    },
  ];

  console.log("REQUEST");

  try {
    const response = await fetch(
      "https://u96i4q2j76.execute-api.us-east-2.amazonaws.com/teste/",
      {
        method: "POST",
        mode: "cors",
        cache: "no-cache",
        credentials: "same-origin",
        headers: {
          "Content-Type": "application/json",
        },
        redirect: "follow",
        referrerPolicy: "no-referrer",
        body: JSON.stringify(data),
      }
    );

    console.log(JSON.stringify(data));

    const result = await response.json();
    // const { predictions } = JSON.parse(result.body);
    // const { predicted_label } = predictions[0];

    console.log("RESPONSE", result);
    predicted_label = result[0];

    if (predicted_label === "0") {
      labelResult.innerHTML = predicted_label + " - CRÉDITO APROVADO";
      labelResult.classList.add("approved");
      labelResult.classList.remove("denied");
    } else {
      labelResult.innerHTML = predicted_label + " - CRÉDITO REJEITADO";
      labelResult.classList.add("denied");
      labelResult.classList.remove("approved");
    }
  } catch (error) {
    labelResult.innerHTML = "ERROR" + error;
    labelResult.classList.add("denied");
    labelResult.classList.remove("approved");
    console.log("ERROR", error);
  }
}

function clean(e) {
  labelResult.innerHTML = "-";
  labelResult.classList.remove("denied");
  labelResult.classList.remove("approved");
}

// Adds a listener for the "submit" event.
form.addEventListener("submit", sendData);
